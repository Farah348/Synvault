# SYNVAULT JSON Database Version

This folder contains the updated SYNVAULT fraud intelligence project using a local JSON file as the database.

## Database

Data is saved here:

```text
BACKEND/data/database.json
```

The JSON file stores:

- `users`
- `statements`
- `transactions`

The browser only stores the active `user_id` and `statement_id` so the pages know which user and uploaded statement are currently active.

## What changed from PostgreSQL

- PostgreSQL is not used.
- SQLAlchemy models are not required.
- Signup, login, upload, fraud detection, analytics, transactions, and chatbot routes are handled by a Python local HTTP server
- The Python backend reads and writes the JSON database file.

## Run

Easiest option:

```text
Double-click START_SYNVAULT.bat
```

That starts the JSON backend and opens the app.

From `new_WORK/BACKEND`:

```powershell
python main.py
```

Then open:

```text
http://127.0.0.1:8000
```

Important: because the app now saves data into a JSON file through the backend, run the backend instead of only opening the HTML file directly.
