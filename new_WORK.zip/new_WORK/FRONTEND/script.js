const API_BASE = window.location.protocol === "file:" ? "http://127.0.0.1:8000" : "";

if (window.location.protocol === "file:") {
    const currentPage = window.location.pathname.split(/[\\/]/).pop() || "index.html";
    window.location.href = `http://127.0.0.1:8000/${currentPage}`;
}

function apiUrl(path) {
    return `${API_BASE}${path}`;
}

function setResult(id, message, color = "var(--cyan)") {
    const element = document.getElementById(id);
    if (!element) return;
    element.innerText = message;
    element.style.color = color;
}

async function signup() {
    const name = document.getElementById("signupName").value.trim();
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value;

    if (!name || !email || !password) {
        setResult("signupResult", "Please fill all signup fields.", "var(--red)");
        return;
    }

    try {
        const response = await fetch(apiUrl("/signup"), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password })
        });
        const data = await response.json();
        setResult("signupResult", data.message, data.message.includes("success") ? "var(--cyan)" : "var(--red)");

        if (data.message.includes("success")) {
            document.getElementById("signupName").value = "";
            document.getElementById("signupEmail").value = "";
            document.getElementById("signupPassword").value = "";
        }
    } catch {
        setResult("signupResult", "Backend is not running. Start the JSON backend first.", "var(--red)");
    }
}

async function login() {
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    try {
        const response = await fetch(apiUrl("/login"), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });
        const data = await response.json();

        setResult("result", data.message, data.message === "Login successful" ? "var(--cyan)" : "var(--red)");

        if (data.message === "Login successful") {
            localStorage.setItem("user_id", data.user_id);
            window.location.href = "upload.html";
        }
    } catch {
        setResult("result", "Backend is not running. Start the JSON backend first.", "var(--red)");
    }
}

function checkLogin() {
    if (!localStorage.getItem("user_id")) {
        window.location.href = "login.html";
    }
}

function logout() {
    localStorage.removeItem("user_id");
    localStorage.removeItem("statement_id");
    window.location.href = "login.html";
}

function goToDashboard() {
    window.location.href = "dashboard.html";
}

async function uploadStatement() {
    const fileInput = document.getElementById("file");
    const file = fileInput.files[0];
    const userId = localStorage.getItem("user_id");

    if (!userId) {
        setResult("uploadResult", "Please login before uploading.", "var(--red)");
        return;
    }

    if (!file) {
        setResult("uploadResult", "Please select a CSV file.", "var(--red)");
        return;
    }

    const formData = new FormData();
    formData.append("user_id", userId);
    formData.append("file", file);

    try {
        const response = await fetch(apiUrl("/upload-statement"), {
            method: "POST",
            body: formData
        });
        const data = await response.json();

        if (!response.ok) {
            setResult("uploadResult", data.detail || "Upload failed.", "var(--red)");
            return;
        }

        localStorage.setItem("statement_id", data.statement_id);
        setResult("uploadResult", `Upload successful. Statement ID: ${data.statement_id}`);
        window.location.href = "dashboard.html";
    } catch (error) {
        setResult("uploadResult", `Upload request failed: ${error.message}`, "var(--red)");
    }
}

async function getCurrentTransactions() {
    const statementId = localStorage.getItem("statement_id");
    if (!statementId) return [];

    const response = await fetch(apiUrl(`/transactions/${statementId}`));
    return response.json();
}

async function getCurrentAnalytics() {
    const statementId = localStorage.getItem("statement_id");
    if (!statementId) {
        return {
            statement_id: null,
            total_transactions: 0,
            total_amount: 0,
            fraud_count: 0,
            safe_count: 0
        };
    }

    const response = await fetch(apiUrl(`/analytics/${statementId}`));
    return response.json();
}

async function buildJsonChatAnswer(question) {
    const statementId = localStorage.getItem("statement_id");

    if (!statementId) {
        return "No transaction data detected. Please upload a statement for analysis.";
    }

    try {
        const response = await fetch(apiUrl("/chat"), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                statement_id: Number(statementId),
                question
            })
        });
        const data = await response.json();
        return data.answer;
    } catch {
        return "The assistant could not reach the JSON backend.";
    }
}
