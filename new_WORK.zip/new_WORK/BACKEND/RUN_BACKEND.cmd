@echo off
cd /d "%~dp0"

set "BUNDLED_PYTHON=C:\Users\syedm\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"

if exist "%BUNDLED_PYTHON%" (
    "%BUNDLED_PYTHON%" main.py
) else (
    python main.py
)

echo.
echo Backend stopped. If there is an error above, send a screenshot of this window.
pause
