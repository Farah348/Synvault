import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)

import cgi
import csv
import hashlib
import json
import shutil
import mimetypes
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse


BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "FRONTEND"
BACKEND_DIR = BASE_DIR / "BACKEND"
DATA_DIR = BACKEND_DIR / "data"
UPLOAD_DIR = BACKEND_DIR / "uploads"
DB_PATH = DATA_DIR / "database.json"

DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


def default_db():
    return {"users": [], "statements": [], "transactions": []}


def read_db():
    if not DB_PATH.exists():
        write_db(default_db())
    try:
        return json.loads(DB_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        write_db(default_db())
        return default_db()


def write_db(data):
    DB_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def next_id(items):
    return max((int(item.get("id", 0)) for item in items), default=0) + 1


def hash_password(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def safe_float(value, default=0.0):
    try:
        return float(str(value).replace(",", "").strip() or default)
    except Exception:
        return default


def safe_int(value, default=0):
    try:
        return int(float(str(value).strip() or default))
    except Exception:
        return default


def risk_level_from_score(score):
    if score >= 6:
        return "Critical"
    if score >= 4:
        return "High"
    if score >= 2:
        return "Medium"
    return "Low"


def detect_fraud(row):
    amount = safe_float(row.get("TransactionAmount", 0))
    description = str(row.get("TransactionType", "")).strip().lower()
    location = str(row.get("Location", "")).strip().lower()
    login_attempts = safe_int(row.get("LoginAttempts", 0))
    account_balance = safe_float(row.get("AccountBalance", 0))
    transaction_duration = safe_float(row.get("TransactionDuration", 0))
    channel = str(row.get("Channel", "")).strip().lower()

    risk_score = 0
    reasons = []

    if abs(amount) > 300:
        risk_score += 2
        reasons.append("High transaction amount")
    if abs(amount) > 1000:
        risk_score += 1
        reasons.append("Very high transaction value")
    if description in ["transfer", "withdrawal"]:
        risk_score += 2
        reasons.append("Risk-sensitive transaction type")
    if description == "debit" and abs(amount) > 700:
        risk_score += 2
        reasons.append("High-value debit transaction")
    if location == "" or "unknown" in location:
        risk_score += 2
        reasons.append("Unknown or missing location")
    if login_attempts > 2:
        risk_score += 2
        reasons.append("Multiple login attempts")
    if login_attempts > 4:
        risk_score += 1
        reasons.append("Excessive login attempts")
    if account_balance < 100 and abs(amount) > 300:
        risk_score += 2
        reasons.append("Low balance after high-value transaction")
    if transaction_duration > 120:
        risk_score += 1
        reasons.append("Unusually long transaction duration")
    if channel in ["unknown", "other"]:
        risk_score += 2
        reasons.append("Suspicious transaction channel")

    return {
        "is_fraud": "Yes" if risk_score >= 3 else "No",
        "risk_score": risk_score,
        "risk_level": risk_level_from_score(risk_score),
        "fraud_reasons": reasons or ["No major risk signals detected"],
    }


def analytics_for_transactions(statement_id, transactions):
    total_transactions = len(transactions)
    total_amount = sum(float(item.get("amount") or 0) for item in transactions)
    fraud_transactions = [item for item in transactions if item.get("is_fraud") == "Yes"]
    safe_count = total_transactions - len(fraud_transactions)
    fraud_count = len(fraud_transactions)
    fraud_total = sum(float(item.get("amount") or 0) for item in fraud_transactions)
    fraud_percentage = (fraud_count / total_transactions) * 100 if total_transactions else 0
    average_amount = total_amount / total_transactions if total_transactions else 0
    average_risk_score = sum(float(item.get("risk_score") or 0) for item in transactions) / total_transactions if total_transactions else 0
    highest_transaction = max(transactions, key=lambda item: float(item.get("amount") or 0), default=None)
    reason_counts = {}

    for item in fraud_transactions:
        for reason in item.get("fraud_reasons", []):
            reason_counts[reason] = reason_counts.get(reason, 0) + 1

    top_reasons = [
        {"reason": reason, "count": count}
        for reason, count in sorted(reason_counts.items(), key=lambda pair: pair[1], reverse=True)[:5]
    ]

    if fraud_percentage >= 25 or average_risk_score >= 4:
        overall_risk_level = "High"
    elif fraud_percentage >= 10 or average_risk_score >= 2:
        overall_risk_level = "Medium"
    else:
        overall_risk_level = "Low"

    return {
        "statement_id": statement_id,
        "total_transactions": total_transactions,
        "total_amount": total_amount,
        "fraud_count": fraud_count,
        "safe_count": safe_count,
        "fraud_percentage": fraud_percentage,
        "fraud_total": fraud_total,
        "average_amount": average_amount,
        "average_risk_score": average_risk_score,
        "highest_transaction": highest_transaction,
        "top_reasons": top_reasons,
        "overall_risk_level": overall_risk_level,
    }


def transactions_for_statement(data, statement_id):
    return [
        item for item in data["transactions"]
        if int(item.get("statement_id", 0)) == statement_id
    ]


class SynvaultHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def send_json(self, payload, status=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json_body(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8")
        return json.loads(body or "{}")

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/api/status":
            self.send_json({
                "message": "Backend is working",
                "storage": "JSON file",
                "database": str(DB_PATH),
            })
            return

        if path.startswith("/transactions/"):
            statement_id = int(path.rsplit("/", 1)[-1])
            data = read_db()
            self.send_json(transactions_for_statement(data, statement_id))
            return

        if path.startswith("/analytics/"):
            statement_id = int(path.rsplit("/", 1)[-1])
            data = read_db()
            transactions = transactions_for_statement(data, statement_id)
            self.send_json(analytics_for_transactions(statement_id, transactions))
            return

        self.serve_frontend(path)

    def do_POST(self):
        path = urlparse(self.path).path

        try:
            if path == "/signup":
                payload = self.read_json_body()
                data = read_db()
                email = payload.get("email", "").strip().lower()

                if any(item["email"] == email for item in data["users"]):
                    self.send_json({"message": "Email already exists"})
                    return

                data["users"].append({
                    "id": next_id(data["users"]),
                    "name": payload.get("name", "").strip(),
                    "email": email,
                    "password": hash_password(payload.get("password", "")),
                })
                write_db(data)
                self.send_json({"message": "User created successfully"})
                return

            if path == "/login":
                payload = self.read_json_body()
                data = read_db()
                email = payload.get("email", "").strip().lower()
                password = hash_password(payload.get("password", ""))
                user = next(
                    (item for item in data["users"] if item["email"] == email and item["password"] == password),
                    None,
                )
                if user:
                    self.send_json({"message": "Login successful", "user_id": user["id"]})
                else:
                    self.send_json({"message": "Invalid credentials"})
                return

            if path == "/upload-statement":
                self.handle_upload_statement()
                return

            if path == "/chat":
                payload = self.read_json_body()
                self.send_json({"answer": self.chat_answer(payload)})
                return

            self.send_json({"message": "Not found"}, status=404)
        except Exception as exc:
            (BACKEND_DIR / "request_error.log").write_text(repr(exc), encoding="utf-8")
            self.send_json({"detail": f"Server error: {exc}"}, status=500)

    def handle_upload_statement(self):
        form = cgi.FieldStorage(
            fp=self.rfile,
            headers=self.headers,
            environ={
                "REQUEST_METHOD": "POST",
                "CONTENT_TYPE": self.headers.get("Content-Type", ""),
                "CONTENT_LENGTH": self.headers.get("Content-Length", "0"),
            },
        )

        user_id = safe_int(form.getvalue("user_id"))
        file_item = form["file"] if "file" in form else None

        if file_item is None or not getattr(file_item, "filename", ""):
            self.send_json({"detail": "No file uploaded"}, status=400)
            return

        data = read_db()
        if not any(int(user["id"]) == user_id for user in data["users"]):
            self.send_json({"detail": "User not found"}, status=404)
            return

        file_name = Path(file_item.filename).name
        file_path = UPLOAD_DIR / file_name

        with file_path.open("wb") as output:
            shutil.copyfileobj(file_item.file, output)

        try:
            with file_path.open("r", encoding="utf-8-sig", newline="") as csv_file:
                rows = list(csv.DictReader(csv_file))
        except Exception as exc:
            self.send_json({"detail": f"CSV could not be processed: {exc}"}, status=400)
            return

        statement_id = next_id(data["statements"])
        data["statements"].append({
            "id": statement_id,
            "user_id": user_id,
            "file_name": file_name,
            "file_path": str(file_path),
        })

        for row in rows:
            fraud_result = detect_fraud(row)
            data["transactions"].append({
                "id": next_id(data["transactions"]),
                "statement_id": statement_id,
                "date": str(row.get("TransactionDate", "")).strip(),
                "description": str(row.get("TransactionType", "")).strip().lower(),
                "amount": safe_float(row.get("TransactionAmount", 0)),
                "is_fraud": fraud_result["is_fraud"],
                "risk_score": fraud_result["risk_score"],
                "risk_level": fraud_result["risk_level"],
                "fraud_reasons": fraud_result["fraud_reasons"],
            })

        write_db(data)
        self.send_json({
            "message": "File uploaded and processed successfully",
            "statement_id": statement_id,
            "file_name": file_name,
        })

    def chat_answer(self, payload):
        statement_id = safe_int(payload.get("statement_id"))
        question = payload.get("question", "").lower()
        transactions = transactions_for_statement(read_db(), statement_id)

        if not transactions:
            return "No transaction data detected. Please upload a statement for analysis."

        fraud_transactions = [item for item in transactions if item.get("is_fraud") == "Yes"]
        safe_transactions = [item for item in transactions if item.get("is_fraud") == "No"]
        analytics = analytics_for_transactions(statement_id, transactions)
        total_amount = sum(float(item.get("amount") or 0) for item in transactions)
        fraud_count = len(fraud_transactions)
        safe_count = len(safe_transactions)
        total_count = len(transactions)
        highest_transaction = max(transactions, key=lambda item: float(item.get("amount") or 0))
        fraud_total = sum(float(item.get("amount") or 0) for item in fraud_transactions)
        fraud_ratio = (fraud_count / total_count) * 100 if total_count else 0

        if "fraud count" in question or ("how many" in question and "fraud" in question):
            return f"Analysis complete. I detected {fraud_count} transactions flagged as potential fraud out of {total_count} total records. This represents approximately {fraud_ratio:.2f}% of all activity."
        if "risk level" in question or "overall risk" in question:
            return f"The overall statement risk level is {analytics['overall_risk_level']}. The fraud exposure is {analytics['fraud_percentage']:.2f}% with an average risk score of {analytics['average_risk_score']:.2f}."
        if "why" in question or "reason" in question or "reasons" in question:
            if not analytics["top_reasons"]:
                return "No dominant fraud reasons were found for this statement."
            reasons = ", ".join(f"{item['reason']} ({item['count']})" for item in analytics["top_reasons"])
            return f"The most common fraud triggers are: {reasons}."
        if "safe count" in question or ("how many" in question and "safe" in question):
            return f"There are {safe_count} transactions marked as safe out of {total_count} total transactions."
        if "total amount" in question:
            return f"The system has processed a total transaction volume of {total_amount:.2f}. This includes both normal and flagged activities."
        if "highest" in question or "largest" in question or "biggest" in question:
            return f"The highest transaction observed is {float(highest_transaction['amount']):.2f}. It is categorized as '{highest_transaction['description']}' and occurred on {highest_transaction['date']}."
        if "suspicious" in question or "pattern" in question:
            return f"I identified {fraud_count} suspicious transactions. The fraud engine evaluates transaction amount, transaction type, location, login attempts, account balance, duration, and channel."
        if "fraud total" in question or ("total" in question and "fraud" in question):
            return f"The cumulative value of all fraud-flagged transactions is {fraud_total:.2f}."
        if "summary" in question or "summarize" in question:
            return (
                f"Here is the statement intelligence summary:\n"
                f"Total Transactions: {total_count}\n"
                f"Fraudulent Transactions: {fraud_count}\n"
                f"Safe Transactions: {safe_count}\n"
                f"Total Transaction Volume: {total_amount:.2f}\n"
                f"Fraud Ratio: {fraud_ratio:.2f}%"
            )

        return "I can provide insights about fraud count, safe count, total amount, highest transaction, fraud total, suspicious patterns, and statement summary."

    def serve_frontend(self, path):
        if path == "/":
            file_path = FRONTEND_DIR / "index.html"
        else:
            file_path = FRONTEND_DIR / path.lstrip("/")

        if not file_path.exists() or not file_path.is_file():
            file_path = FRONTEND_DIR / "index.html"

        content_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        body = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    try:
        server = ThreadingHTTPServer(("127.0.0.1", 8000), SynvaultHandler)
        print("SYNVAULT JSON backend running at http://127.0.0.1:8000", flush=True)
        print(f"JSON database: {DB_PATH}", flush=True)
        server.serve_forever()
    except Exception as exc:
        (BACKEND_DIR / "server_error.log").write_text(repr(exc), encoding="utf-8")
        raise
